#ifndef AST_H
#define AST_H

#include <stdbool.h>
#include "tokenizer.h"
#include "types.h"

typedef enum {
  NODE_EXPRESION,
  NODE_DECLAR,
  NODE_IF_CONDITION,
  NODE_ARRAY_ACCESS,
  NODE_ASSIGN,
  NODE_EQUALS_SIGN,
  NODE_OPERATION,
  NODE_INT,
  NODE_FLOAT,
  NODE_ARRAY,
  NODE_KEYWORD,
  NODE_BRACKET_OPEN,
  NODE_BRACKET_CLOSE,
  NODE_GOTO,
  NODE_BLOCK,
  NODE_TYPE,
  NODE_IDENTIFYER,
  NODE_PARAMETER_DECLARATION,
  NODE_FUNCTION_DECLARATION,
  NODE_FUNCTION_CALL,
  NODE_PARAMETER,
  NODE_RETURN,
  NODE_LABLE,
  NODE_ROOT
} ast_type;

typedef struct ast ast;

typedef struct ast {
  ast_type type;
  ast *next_statement;
  union {
    struct LITTERAL {
      value value;
    } LITTERAL;
    struct IDENTIFYER {
      char *name;
    } IDENTIFYER;
    struct EXPRESSION {
      ast *lhs;
      ast *rhs;
      enum token_type operaton;
    } EXPRESSION;
    struct DECLARE {
      ast *identifyer;
      build_in_types type;
      bool array;
      ast *size; // array size
      ast *expression;
      ast **array_values;
      int array_count;
    } DECLARE;
    struct ASSIGN {
      ast *identifyer;
      ast *expression;
    } ASSIGN;
    struct ARRAY_ACCESS {
      ast *identifyer;
      ast *index;
    } ARRAY_ACCESS;
    struct IF {
      ast *condition;
      ast *if_body;
      ast *else_body;
    } IF;
    struct GOTO {
      ast *identifyer;
    } GOTO;
    struct BLOCK {
      ast **array;
      int count;
    } BLOCK;
    struct TYPE {
      build_in_types type;
      ast *rhs;
    } TYPE;
    struct FUNCTION_DECLARATION {
      ast *return_type;
      ast *identifyer;
      ast *parameter;
      ast *block;
    } FUNCTION_DECLARATION;
    struct PARAMETER_DECLARATION {
      ast *type;
      ast *name;
      ast *next_param;
    } PARAMETER_DECLARATION;
    struct FUNCTION_CALL {
      char *name;
      ast *params;
    } FUNCTION_CALL;
    struct PARAMETER {
      ast *expression;
      ast *next_param;
    } PARAMETER;
    struct RETURN {
      ast *expression;
    } RETURN;
    struct LABLE {
      ast *identifyer;
    } LABLE;
  } data;
} ast;

typedef struct {
  int left;
  int right;
} binding_power;

binding_power get_binding_power(enum token_type type);
ast_type token_type_to_ast_type(enum token_type type);
ast *clone_ast(ast *source);
void print_ast(ast *node, int depth);

#endif
