void register_functions();
