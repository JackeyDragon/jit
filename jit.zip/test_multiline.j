int mult(int x, int y) {
    return x * y;
  }

int add(int x, int y) {
    x = mult(x, y);
    return 0;
  }

print(add(1,2));
